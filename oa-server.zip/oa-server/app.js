const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// 创建Express实例
const app = express();
app.use(cors()); // 允许跨域
app.use(express.json()); // 解析JSON请求

// 1. 数据库连接
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  charset: 'utf8mb4'
});

// 测试数据库连接
pool.execute('SELECT 1').then(() => {
  console.log('数据库连接成功 ✅');
}).catch(err => {
  console.error('数据库连接失败 ❌：', err);
  process.exit(1);
});

// 2. JWT鉴权中间件
const auth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ code: 401, msg: '未登录' });
    
    const user = jwt.verify(token, process.env.JWT_SECRET);
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ code: 401, msg: 'token无效/过期' });
  }
};

// 3. 登录接口
app.post('/api/user/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    // 简化版：查询用户（密码用md5的123456）
    const [users] = await pool.execute(
      'SELECT id, username, name FROM users WHERE username = ? AND password = ?',
      [username, 'e10adc3949ba59abbe56e057f20f883e']
    );

    if (users.length === 0) {
      return res.status(401).json({ code: 401, msg: '用户名/密码错误' });
    }

    // 生成token
    const token = jwt.sign({ id: users[0].id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });
    
    res.json({
      code: 200,
      msg: '登录成功',
      data: {
        token,
        userInfo: { name: users[0].name }
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 4. 首页数据接口（从数据库查询真实数据）
app.get('/api/dashboard/data', auth, async (req, res) => {
  try {
    // -------------- 替换核心：从数据库查询数据 --------------
    // 4.1 查询功能菜单（function_list表）
    const [functionList] = await pool.execute('SELECT name, icon, path FROM function_list');
    
    // 4.2 查询待办统计（todo表）
    const [todoStatsPending] = await pool.execute('SELECT COUNT(*) as count FROM todo WHERE status = 0'); // 0=待处理
    const [todoStatsProcessing] = await pool.execute('SELECT COUNT(*) as count FROM todo WHERE status = 1'); // 1=处理中
    const [todoStatsCompleted] = await pool.execute('SELECT COUNT(*) as count FROM todo WHERE status = 2'); // 2=已完成
    const todoStats = {
      pending: todoStatsPending[0].count,
      processing: todoStatsProcessing[0].count,
      completed: todoStatsCompleted[0].count
    };

    // 4.3 查询进行中待办（todo表）
    const [processingTodos] = await pool.execute(`
      SELECT t.id, t.title, u.name as user, t.create_time as time 
      FROM todo t 
      LEFT JOIN users u ON t.create_user_id = u.id 
      WHERE t.status = 1
    `);

    // 4.4 查询今日日程（schedule表）
    const today = new Date().toISOString().split('T')[0]; // 获取今天日期（格式：2026-01-30）
    const [todaySchedule] = await pool.execute(`
      SELECT id, time, title 
      FROM schedule 
      WHERE DATE(date) = ? AND user_id = ?
    `, [today, req.user.id]); // 只查当前登录用户的今日日程

    // 4.5 查询天气（weather表，简化：只取最新一条）
    const [weatherList] = await pool.execute('SELECT icon, text, temp, tips FROM weather ORDER BY id DESC LIMIT 1');
    const weather = weatherList.length > 0 ? weatherList[0] : { icon: '☀️', text: '晴', temp: 25, tips: '今日防晒' };

    // 组装返回数据
    const data = {
      functionList,
      todoStats,
      processingTodos,
      todaySchedule,
      weather
    };

    res.json({ code: 200, msg: '成功', data });
  } catch (err) {
    console.error('首页数据查询失败：', err); // 打印错误便于调试
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});
// 5. 电子邮件列表接口
app.get('/api/email/list', auth, async (req, res) => {
  try {
    const username = '李佳';
    const [emails] = await pool.execute(`
      SELECT id, from_user, subject, send_time, is_read 
      FROM email 
      WHERE to_user = ? 
      ORDER BY send_time DESC
    `, [username]);
    res.json({ code: 200, msg: '成功', data: emails });
  } catch (err) {
    console.error('邮件列表查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 6. 待办事项列表接口
app.get('/api/todo/list', auth, async (req, res) => {
  try {
    const { status } = req.query;
    let sql = 'SELECT id, title, content, status, create_time FROM todo WHERE create_user_id = ?';
    let params = [req.user.id];

    if (status !== undefined) {
      sql += ' AND status = ?';
      params.push(status);
    }

    const [todos] = await pool.execute(sql, params);
    res.json({ code: 200, msg: '成功', data: todos });
  } catch (err) {
    console.error('待办列表查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 7. 考勤统计接口
app.get('/api/attendance/list', auth, async (req, res) => {
  try {
    const [attendance] = await pool.execute(`
      SELECT date, check_in_time, check_out_time, status 
      FROM attendance 
      WHERE user_id = ? 
      ORDER BY date DESC
    `, [req.user.id]);
    res.json({ code: 200, msg: '成功', data: attendance });
  } catch (err) {
    console.error('考勤列表查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 8. 公告通知接口
app.get('/api/notice/list', auth, async (req, res) => {
  try {
    const [notices] = await pool.execute(`
      SELECT id, title, content, publish_user, publish_time, is_top 
      FROM notice 
      ORDER BY is_top DESC, publish_time DESC
    `);
    res.json({ code: 200, msg: '成功', data: notices });
  } catch (err) {
    console.error('公告列表查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 9. 工作汇报接口
app.get('/api/report/list', auth, async (req, res) => {
  try {
    const [reports] = await pool.execute(`
      SELECT id, title, content, report_date, create_time 
      FROM report 
      WHERE user_id = ? 
      ORDER BY report_date DESC
    `, [req.user.id]);
    res.json({ code: 200, msg: '成功', data: reports });
  } catch (err) {
    console.error('汇报列表查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 10. 通讯录接口
app.get('/api/contact/list', auth, async (req, res) => {
  try {
    const [contacts] = await pool.execute('SELECT id, name, department, position, email, phone FROM contact ORDER BY department, name');
    res.json({ code: 200, msg: '成功', data: contacts });
  } catch (err) {
    console.error('通讯录查询失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});
// 11. 应用中心接口
app.get('/api/app/list', auth, async (req, res) => {
  try {
    const { type } = req.query;
    let sql = 'SELECT id, name, icon, color, desc, recommend FROM app WHERE type = ? ORDER BY sort ASC';
    const [apps] = await pool.execute(sql, [type]);
    res.json({ code: 200, msg: '成功', data: apps });
  } catch (err) {
    console.error('获取应用列表失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});
// 12. 日程相关接口
app.get('/api/calendar/list', auth, async (req, res) => {
  try {
    const [calendar] = await pool.execute('SELECT id, date, time, title, remark FROM schedule WHERE user_id = ?', [req.user.id]);
    res.json({ code: 200, msg: '成功', data: calendar });
  } catch (err) {
    console.error('获取日程失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.post('/api/calendar/add', auth, async (req, res) => {
  try {
    const { date, time, title, remark } = req.body;
    await pool.execute(
      'INSERT INTO schedule (user_id, title, date, time, address) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, title, date, time, remark || '']
    );
    res.json({ code: 200, msg: '新增成功' });
  } catch (err) {
    console.error('新增日程失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.put('/api/calendar/edit/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { date, time, title, remark } = req.body;
    await pool.execute(
      'UPDATE schedule SET title = ?, date = ?, time = ?, address = ? WHERE id = ? AND user_id = ?',
      [title, date, time, remark || '', id, req.user.id]
    );
    res.json({ code: 200, msg: '编辑成功' });
  } catch (err) {
    console.error('编辑日程失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.delete('/api/calendar/delete/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('DELETE FROM schedule WHERE id = ? AND user_id = ?', [id, req.user.id]);
    res.json({ code: 200, msg: '删除成功' });
  } catch (err) {
    console.error('删除日程失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 13. 通讯录接口
app.get('/api/contact/list', auth, async (req, res) => {
  try {
    const { dept } = req.query;
    let sql = 'SELECT name, dept as department, position, phone, email, office, joinTime, avatar FROM contact';
    const params = [];
    
    if (dept && dept !== 'all') {
      sql += ' WHERE dept = ?';
      params.push(dept);
    }
    
    const [contacts] = await pool.execute(sql, params);
    // 补充默认数据
    const result = contacts.map(item => ({
      ...item,
      office: item.office || '未分配',
      joinTime: item.joinTime || '2026-01-01',
      avatar: item.avatar || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'
    }));
    res.json({ code: 200, msg: '成功', data: result });
  } catch (err) {
    console.error('获取通讯录失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 14. 邮件相关接口
app.get('/api/email/list', auth, async (req, res) => {
  try {
    const { type, keyword } = req.query;
    let sql = 'SELECT id, subject, from_user as sender, send_time as time, is_read as read FROM email WHERE to_user = ?';
    const params = ['李佳'];
    
    if (type === 'unread') {
      sql += ' AND is_read = 0';
    } else if (type === 'read') {
      sql += ' AND is_read = 1';
    }
    
    if (keyword) {
      sql += ' AND (subject LIKE ? OR from_user LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }
    
    const [emails] = await pool.execute(sql, params);
    res.json({ code: 200, msg: '成功', data: emails });
  } catch (err) {
    console.error('获取邮件失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.put('/api/email/read/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('UPDATE email SET is_read = 1 WHERE id = ?', [id]);
    res.json({ code: 200, msg: '标记成功' });
  } catch (err) {
    console.error('标记邮件失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 15. 公告接口
app.get('/api/notice/list', auth, async (req, res) => {
  try {
    const [notices] = await pool.execute(`
      SELECT id, title, content, publish_user as publisher, publish_time as time, 
      CASE WHEN publish_user = '系统管理员' THEN '技术部' ELSE publish_user END as department 
      FROM notice ORDER BY is_top DESC, publish_time DESC
    `);
    res.json({ code: 200, msg: '成功', data: notices });
  } catch (err) {
    console.error('获取公告失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 16. 工作汇报接口
app.get('/api/report/list', auth, async (req, res) => {
  try {
    const [reports] = await pool.execute(`
      SELECT id, title, 
      CASE WHEN title LIKE '%周%' THEN '周报' WHEN title LIKE '%月%' THEN '月报' ELSE '其他' END as type,
      report_date as period, '已提交' as status, content 
      FROM report WHERE user_id = ?
    `, [req.user.id]);
    res.json({ code: 200, msg: '成功', data: reports });
  } catch (err) {
    console.error('获取汇报失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.post('/api/report/draft', auth, async (req, res) => {
  try {
    const { title, type, period, content } = req.body;
    await pool.execute(
      'INSERT INTO report (user_id, user_name, title, content, report_date) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, '李佳', title, content, period]
    );
    res.json({ code: 200, msg: '保存成功' });
  } catch (err) {
    console.error('保存汇报失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.post('/api/report/submit', auth, async (req, res) => {
  try {
    const { title, type, period, content } = req.body;
    await pool.execute(
      'INSERT INTO report (user_id, user_name, title, content, report_date) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, '李佳', title, content, period]
    );
    res.json({ code: 200, msg: '提交成功' });
  } catch (err) {
    console.error('提交汇报失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

// 17. 待办详情和状态更新
app.get('/api/todo/detail/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const [todo] = await pool.execute(`
      SELECT t.id, t.title, u.name as user, t.create_time as time,
      CASE t.status 
        WHEN 0 THEN 'processing' 
        WHEN 1 THEN 'processing' 
        WHEN 2 THEN 'completed' 
        ELSE 'rejected' 
      END as status, t.content
      FROM todo t LEFT JOIN users u ON t.create_user_id = u.id WHERE t.id = ?
    `, [id]);
    res.json({ code: 200, msg: '成功', data: todo[0] });
  } catch (err) {
    console.error('获取待办详情失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});

app.put('/api/todo/status/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.query;
    let statusCode = 2; // 已完成
    if (status === 'rejected') statusCode = 3; // 驳回
    
    await pool.execute('UPDATE todo SET status = ? WHERE id = ?', [statusCode, id]);
    res.json({ code: 200, msg: '操作成功' });
  } catch (err) {
    console.error('更新待办状态失败：', err);
    res.status(500).json({ code: 500, msg: '服务器错误' });
  }
});
// 启动服务
app.listen(process.env.PORT, () => {
  console.log(`后端服务运行在：http://localhost:${process.env.PORT} 🚀`);
});