import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import App from './App.vue'
import router from './router'

// 新增：注册Pinia
import { createPinia } from 'pinia'
const pinia = createPinia()

// 新增：开发环境启动Mock接口（生产环境注释掉）
if (import.meta.env.DEV) {
  import('./mock/index.ts');
}

const app = createApp(App)

app.use(router)
app.use(ElementPlus)
app.use(pinia) // 新增：使用Pinia

app.mount('#app')
