<template>
  <div class="main-layout">
    <!-- 侧边栏 -->
    <div class="sidebar">
      <div class="logo">OA办公系统</div>
      <el-menu
        :default-active="$route.path"
        class="sidebar-menu"
        background-color="#fff"
        text-color="#333"
        active-text-color="#409eff"
      >
        <!-- 所有菜单都绑定@click手动跳转 -->
        <el-menu-item index="/" @click="goTo('/')">
          <el-icon><House /></el-icon>
          <span>首页</span>
        </el-menu-item>

        <el-sub-menu index="1">
          <template #title>
            <el-icon><Document /></el-icon>
            <span>待办管理</span>
          </template>
          <el-menu-item index="/todo" @click="goTo('/todo')">待办列表</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/attendance" @click="goTo('/attendance')">
          <el-icon><Clock /></el-icon>
          <span>考勤统计</span>
        </el-menu-item>

        <el-menu-item index="/email" @click="goTo('/email')">
          <el-icon><Message /></el-icon>
          <span>电子邮件</span>
        </el-menu-item>

        <el-menu-item index="/calendar" @click="goTo('/calendar')">
          <el-icon><Calendar /></el-icon>
          <span>我的日程</span>
        </el-menu-item>

        <el-menu-item index="/notice" @click="goTo('/notice')">
          <el-icon><Bell /></el-icon>
          <span>公告通知</span>
        </el-menu-item>

        <el-menu-item index="/report" @click="goTo('/report')">
          <el-icon><Files /></el-icon>
          <span>工作汇报</span>
        </el-menu-item>

        <el-menu-item index="/contact" @click="goTo('/contact')">
          <el-icon><User /></el-icon>
          <span>通讯录</span>
        </el-menu-item>

        <el-menu-item index="/apps" @click="goTo('/apps')">
          <el-icon><Grid /></el-icon>
          <span>应用中心</span>
        </el-menu-item>
      </el-menu>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <div class="top-nav">
        <div class="user-info">
          欢迎回来，{{ userStore.userInfo.name || '管理员' }}
        </div>
        <el-button type="text" @click="handleLogout">退出登录</el-button>
      </div>
      <router-view :key="$route.fullPath" /> <!-- 强制刷新 -->
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import {
  House, Document, Clock, Message, Calendar,
  Bell, Files, User, Grid // 补全File图标导入
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

const goTo = (path: string) => {
  router.replace(path) // 无刷新跳转，避免页面重载
}

// 退出登录
const handleLogout = () => {
  userStore.logout()
  ElMessage.success('退出登录成功！')
  window.location.href = '/login'
}
</script>

<style scoped>
.main-layout {
  display: flex;
  height: 100vh;
  width: 100%;
  overflow: hidden;
}

.sidebar {
  width: 200px;
  background: #fff;
  border-right: 1px solid #eee;
  height: 100%;
}

.logo {
  padding: 20px;
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  border-bottom: 1px solid #eee;
  background-color: #f8f9fa;
}

.sidebar-menu {
  border-right: none;
  height: calc(100% - 70px);
}

:deep(.el-menu) {
  border-right: none;
}

:deep(.el-sub-menu__title) {
  color: #333 !important;
}

.main-content {
  flex: 1;
  background: #f5f7fa;
  overflow: auto;
  height: 100%;
}

.top-nav {
  padding: 15px 20px;
  background: #fff;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  border-bottom: 1px solid #eee;
}

.user-info {
  margin-right: 20px;
  color: #666;
}
</style>
