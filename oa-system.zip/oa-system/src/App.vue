<template>
  <!-- 路由出口：登录页/布局页面都在这里显示 -->
  <router-view />
</template>

<script setup lang="ts">
// 只保留路由出口
</script>

<style scoped>
/* 清空原有样式，布局样式都在MainLayout里 */
</style>
