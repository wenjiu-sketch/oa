import { defineStore } from 'pinia';

export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}'),
    sidebarCollapse: false
  }),

  getters: {
    // 判断是否登录
    isLoggedIn: (state) => !!state.token,
    userRole: (state) => state.userInfo.role || 'user'
  },

  actions: {
    // 登录
    login(token: string, userInfo: unknown) {
      this.token = token;
      this.userInfo = userInfo;
      localStorage.setItem('token', token);
      localStorage.setItem('userInfo', JSON.stringify(userInfo));
    },

    // 退出登录（核心：清空所有状态）
    logout() {
      this.token = '';
      this.userInfo = {};
      localStorage.removeItem('token');
      localStorage.removeItem('userInfo');
    },

    // 切换侧边栏
    toggleSidebar() {
      this.sidebarCollapse = !this.sidebarCollapse;
    }
  }
});
