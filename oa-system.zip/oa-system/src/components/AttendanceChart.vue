<template>
  <div class="attendance-chart">
    <h4>本月考勤</h4>
    <v-chart :option="chartOption" :autoresize="true" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart } from 'echarts/charts'
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components'

// 注册 ECharts 模块
use([CanvasRenderer, PieChart, TitleComponent, TooltipComponent, LegendComponent])

// 考勤数据
const chartOption = ref({
  tooltip: {
    trigger: 'item'
  },
  legend: {
    orient: 'vertical',
    right: 10,
    top: 'center'
  },
  series: [
    {
      name: '考勤',
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 10,
        borderColor: '#fff',
        borderWidth: 2
      },
      label: {
        show: false,
        position: 'center'
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 20,
          fontWeight: 'bold'
        }
      },
      labelLine: {
        show: false
      },
      data: [
        { value: 22, name: '正常打卡' },
        { value: 3, name: '迟到' },
        { value: 1, name: '早退' },
        { value: 2, name: '缺卡' }
      ]
    }
  ]
})
</script>

<style scoped>
.attendance-chart {
  height: 200px;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
