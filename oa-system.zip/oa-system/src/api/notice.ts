import request from '@/utils/request'

// 获取公告列表
export const getNoticeListApi = () => {
  return request({
    url: '/api/notice/list',
    method: 'get',
  })
}
