import request from '@/utils/request'

// 登录接口
export const loginApi = (data: { username: string; password: string }) => {
  return request({
    url: '/api/login',
    method: 'post',
    data,
  })
}

// 获取用户信息接口（可选）
export const getUserInfoApi = () => {
  return request({
    url: '/api/user/info',
    method: 'get',
  })
}
