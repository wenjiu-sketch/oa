import request from '@/utils/request'

// 获取考勤数据
export const getAttendanceDataApi = () => {
  return request({
    url: '/api/attendance/list',
    method: 'get',
  })
}
