import request from '@/utils/request'

// 获取应用列表（按类型）
export const getAppListApi = (params: { type: string }) => {
  return request({
    url: '/api/app/list',
    method: 'get',
    params,
  })
}
