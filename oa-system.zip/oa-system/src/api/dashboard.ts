import request from '@/utils/request'

// 获取首页数据（待办+常用功能）
export const getDashboardDataApi = () => {
  return request({
    url: '/api/dashboard/data',
    method: 'get',
  })
}
