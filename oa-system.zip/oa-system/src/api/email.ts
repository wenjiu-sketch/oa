import request from '@/utils/request'

// 获取邮件列表（筛选）
export const getEmailListApi = (params: { type: string; keyword: string }) => {
  return request({
    url: '/api/email/list',
    method: 'get',
    params,
  })
}

// 标记邮件为已读
export const markEmailReadApi = (id: number) => {
  return request({
    url: `/api/email/read/${id}`,
    method: 'put',
  })
}
