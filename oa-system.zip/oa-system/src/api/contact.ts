import request from '@/utils/request'

// 获取通讯录列表（按部门筛选）
export const getContactListApi = (params: { dept: string }) => {
  return request({
    url: '/api/contact/list',
    method: 'get',
    params,
  })
}
