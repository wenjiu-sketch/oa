import request from '@/utils/request'

// 获取汇报列表
export const getReportListApi = () => {
  return request({
    url: '/api/report/list',
    method: 'get',
  })
}

// 保存汇报（草稿）
export const saveReportDraftApi = (data: {
  title: string
  type: string
  period: string
  content: string
}) => {
  return request({
    url: '/api/report/draft',
    method: 'post',
    data,
  })
}

// 提交汇报
export const submitReportApi = (data: {
  title: string
  type: string
  period: string
  content: string
}) => {
  return request({
    url: '/api/report/submit',
    method: 'post',
    data,
  })
}
