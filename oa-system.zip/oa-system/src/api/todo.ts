import request from '@/utils/request'

// 获取待办列表（支持分页）
export const getTodoListApi = (params: { pageNum: number; pageSize: number }) => {
  return request({
    url: '/api/todo/list',
    method: 'get',
    params, // 传递分页参数
  })
}

// 获取待办详情
export const getTodoDetailApi = (id: number) => {
  return request({
    url: `/api/todo/detail/${id}`,
    method: 'get',
  })
}

// 可选：新增待办
export const addTodoApi = (data: unknown) => {
  return request({
    url: '/api/todo/add',
    method: 'post',
    data,
  })
}

// 可选：更新待办状态
export const updateTodoStatusApi = (id: number, status: string) => {
  return request({
    url: `/api/todo/status/${id}`,
    method: 'put',
    data: { status },
  })
}
