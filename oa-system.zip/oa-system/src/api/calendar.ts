import request from '@/utils/request'

// 获取日程列表
export const getCalendarListApi = () => {
  return request({
    url: '/api/calendar/list',
    method: 'get',
  })
}
// 新增日程
export const addCalendarApi = (data: {
  date: string
  time: string
  title: string
  remark: string
}) => {
  return request({
    url: '/calendar/add',
    method: 'post',
    data,
  })
}

// 编辑日程
export const editCalendarApi = (
  id: number,
  data: {
    date: string
    time: string
    title: string
    remark: string
  },
) => {
  return request({
    url: `/calendar/edit/${id}`,
    method: 'put',
    data,
  })
}

// 删除日程
export const deleteCalendarApi = (id: number) => {
  return request({
    url: `/calendar/delete/${id}`,
    method: 'delete',
  })
}
