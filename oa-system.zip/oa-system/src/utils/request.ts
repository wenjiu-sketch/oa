import axios from 'axios';
import { ElMessage, ElMessageBox } from 'element-plus';
import { useUserStore } from '@/stores/user';
import { useRouter } from 'vue-router';

// 创建 axios 实例
const service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL, // 从环境变量取接口地址
  timeout: 10000, // 超时时间
});

// 请求拦截器：给所有请求加 token
service.interceptors.request.use(
  (config) => {
    const userStore = useUserStore();
    if (userStore.token) {
      config.headers.Authorization = `Bearer ${userStore.token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器：统一处理错误和 token 过期
service.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const userStore = useUserStore();
    const router = useRouter();

    // 401 表示 token 过期或未登录
    if (error.response?.status === 401) {
      ElMessageBox.confirm(
        '登录已过期，请重新登录',
        '提示',
        {
          confirmButtonText: '确定',
          type: 'warning',
        }
      ).then(() => {
        userStore.logout();
        router.push('/login');
      });
    }

    // 统一提示错误信息
    ElMessage.error(error.response?.data?.msg || '请求失败，请稍后重试');
    return Promise.reject(error);
  }
);

export default service;
