<template>
  <div class="todo-list-container">
    <el-card>
      <!-- 卡片头部 -->
      <template #header>
        <div class="card-header">
          <span>全部待办工作 ({{ total }})</span>
          <el-button type="text" @click="loadTodoList()" :loading="loading">
            <el-icon><Refresh /></el-icon> 刷新
          </el-button>
        </div>
      </template>

      <!-- 表格区域 -->
      <div class="table-wrapper">
        <!-- 加载中 -->
        <div v-if="loading" class="loading-tip">加载中...</div>

        <!-- 空数据 -->
        <div v-else-if="tableData.length === 0" class="empty-tip">
          <el-empty description="暂无待办工作数据" />
        </div>

        <!-- 表格 -->
        <el-table v-else :data="tableData" border stripe style="width: 100%">
          <el-table-column prop="id" label="编号" width="80" align="center" />
          <el-table-column prop="title" label="标题" min-width="200" />
          <el-table-column prop="user" label="申请人" width="100" align="center" />
          <el-table-column prop="time" label="申请时间" width="180" align="center" />
          <el-table-column prop="status" label="状态" width="100" align="center">
            <template #default="">
              <el-tag type="primary" size="small">办理中</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="120" align="center">
            <template #default="{ row }">
              <el-button type="primary" size="small" @click="goToDetail(row.id)">
                <el-icon><View /></el-icon> 查看详情
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 分页 -->
      <div class="pagination-wrapper" v-if="total > 0">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :total="total"
          layout="total, prev, pager, next"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
// 核心：先导入Element Plus图标（很多人漏了这个！）
import { Refresh, View } from '@element-plus/icons-vue'
import { ref, onMounted,watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getTodoListApi } from '@/api/todo'
import { useRoute } from "vue-router"

// 1. 简单类型定义（先保证不报错）
interface TableItem {
  id: number
  title: string
  user: string
  time: string
  status: string
}

// 2. 路由实例
const router = useRouter()
const route = useRoute()
// 3. 响应式数据（极简版）
const loading = ref<boolean>(false)
const pageNum = ref<number>(1)
const pageSize = ref<number>(10)
const total = ref<number>(0)
const tableData = ref<TableItem[]>([])

// 4. 页面加载时获取数据
onMounted(() => {
  loadTodoList()
})

// 5. 加载数据（直接写死请求逻辑，避免api层报错）
const loadTodoList = async () => {
  try {
    loading.value = true
    const res = await getTodoListApi({
      pageNum:pageNum.value,
      pageSize:pageSize.value
    })
    // 赋值数据
    tableData.value = res.data.list
    total.value = res.data.total
    ElMessage.success('待办列表加载成功')
  } catch (error) {
    console.error('加载失败：', error)
    ElMessage.error('加载失败，显示本地数据')
    // 兜底数据
    tableData.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

// 6. 分页切换
const handleCurrentChange = (val: number) => {
  pageNum.value = val
  loadTodoList()}

// 7. 跳转详情页
const goToDetail = (id: number) => {
  try {
    router.push({
      name: 'TodoDetail',
      params: { id }
    })
  } catch (error) {
    ElMessage.error('跳转失败，请检查路由配置')
    console.error('跳转错误：', error)
  }
}
// 监听路由变化，重新加载数据
const loadData = async () => {
  // 你的数据请求逻辑
};

onMounted(() => {
  loadData();
});

watch(
  () => route.path,
  () => {
    loadData();
  }
);
</script>

<style scoped>
.todo-list-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: calc(100vh - 104px);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.table-wrapper {
  margin-bottom: 20px;
}

.loading-tip {
  padding: 40px 0;
  text-align: center;
  color: #666;
}

.empty-tip {
  padding: 40px 0;
  text-align: center;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

/* 基础样式优化 */
:deep(.el-table) {
  background: #fff;
}
:deep(.el-card) {
  box-shadow: 0 2px 12px rgba(0,0,0,0.05);
}
</style>
