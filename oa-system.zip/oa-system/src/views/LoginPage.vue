<template>
  <div class="login-page">
    <el-card class="login-card">
      <div class="login-title">OA办公系统登录</div>

      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="80px"
        class="login-form"
      >
        <el-form-item label="用户名" prop="username">
          <el-input
            v-model="form.username"
            placeholder="请输入用户名"
            prefix-icon="User"
          />
        </el-form-item>

        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            type="password"
            placeholder="请输入密码"
            prefix-icon="Lock"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            @click="handleLogin"
            class="login-btn"
            block
          >
            登录
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { useUserStore } from '@/stores/user';
import { ElMessage } from 'element-plus';
import { loginApi } from '@/api/user';

// 表单引用
const formRef = ref();

// 表单数据
const form = reactive({
  username: 'admin', // 默认值，方便测试
  password: '123456'
});

// 表单校验规则（企业级必备）
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度在3-20个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度在6-20个字符', trigger: 'blur' }
  ]
};

// 路由和状态
const router = useRouter();
const userStore = useUserStore();

// 登录方法
const handleLogin = async () => {
  // 先校验表单
  const valid = await formRef.value?.validate();
  if (!valid) return;

  try {
    // 调用登录接口
    const res = await loginApi(form);
    // 保存用户状态
    userStore.login(res.data.token, res.data.userInfo);
    ElMessage.success('登录成功');
    // 跳首页
    router.push('/');
  } catch (error) {
    console.error('登录失败：', error);
  }
};
</script>

<style scoped>
.login-page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.login-card {
  width: 400px;
  padding: 30px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

.login-title {
  text-align: center;
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 20px;
  color: #333;
}

.login-form {
  margin-top: 20px;
}

.login-btn {
  margin-top: 10px;
}
</style>
