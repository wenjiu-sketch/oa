<template>
  <div class="notice-page">
    <el-card class="page-header">
      <template #header>
        <span>公告通知</span>
      </template>
      <p>公司及部门最新公告、制度更新</p>
    </el-card>

    <!-- 公告列表 -->
    <el-card>
      <el-timeline>
        <el-timeline-item
          v-for="notice in noticeList"
          :key="notice.id"
          :timestamp="notice.time"
          placement="top"
        >
          <el-card>
            <h4>{{ notice.title }}</h4>
            <p class="notice-content">{{ notice.content }}</p>
            <p class="notice-source">发布部门：{{ notice.department }} | 发布人：{{ notice.publisher }}</p>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getNoticeListApi } from '@/api/notice'

// 类型定义
interface NoticeItem {
  id: number
  title: string
  content: string
  department: string
  publisher: string
  time: string
}

// 响应式数据
const noticeList = ref<NoticeItem[]>([])

// 页面加载时获取公告
onMounted(async () => {
  try {
    const res = await getNoticeListApi()
    noticeList.value = res.data
  } catch (error) {
    console.error('获取公告失败：', error)
    noticeList.value = []
  }
})
</script>

<style scoped>
.notice-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.notice-content {
  color: #666;
  line-height: 1.6;
  margin: 10px 0;
}

.notice-source {
  font-size: 12px;
  color: #999;
}
</style>
