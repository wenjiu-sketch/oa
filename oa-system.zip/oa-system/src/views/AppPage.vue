<template>
  <div class="apps-page">
    <el-card class="page-header">
      <template #header>
        <span>应用中心</span>
      </template>
      <p>公司内部应用集成入口</p>
    </el-card>

    <!-- 应用分类 -->
    <el-card style="margin-bottom: 20px;">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="办公应用" name="office" />
        <el-tab-pane label="业务系统" name="business" />
        <el-tab-pane label="工具类" name="tools" />
      </el-tabs>
    </el-card>

    <!-- 应用列表 -->
    <el-card>
      <el-row :gutter="20">
        <!-- 办公应用 -->
        <template v-if="activeTab === 'office'">
          <el-col :span="6" v-for="app in officeApps" :key="app.id">
            <div class="app-card" @click="openApp(app)">
              <el-icon :size="36" :color="app.color">  <component :is="app.icon" /></el-icon>
              <h4>{{ app.name }}</h4>
              <p class="app-desc">{{ app.desc }}</p>
              <div class="app-tag" v-if="app.recommend">推荐</div>
            </div>
          </el-col>
        </template>

        <!-- 业务系统 -->
        <template v-if="activeTab === 'business'">
          <el-col :span="6" v-for="app in businessApps" :key="app.id">
            <div class="app-card" @click="openApp(app)">
              <el-icon :size="36" :color="app.color">  <component :is="app.icon" /></el-icon>
              <h4>{{ app.name }}</h4>
              <p class="app-desc">{{ app.desc }}</p>
            </div>
          </el-col>
        </template>

        <!-- 工具类 -->
        <template v-if="activeTab === 'tools'">
          <el-col :span="6" v-for="app in toolApps" :key="app.id">
            <div class="app-card" @click="openApp(app)">
              <el-icon :size="36" :color="app.color">  <component :is="app.icon" /></el-icon>
              <h4>{{ app.name }}</h4>
              <p class="app-desc">{{ app.desc }}</p>
            </div>
          </el-col>
        </template>
      </el-row>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { getAppListApi } from '@/api/app'

// 类型定义
interface AppItem {
  id: number
  name: string
  icon: string
  color: string
  desc: string
  recommend?: boolean
}

// 响应式数据
const router = useRouter()
const activeTab = ref<string>('office')
const officeApps = ref<AppItem[]>([])
const businessApps = ref<AppItem[]>([])
const toolApps = ref<AppItem[]>([])

// 监听标签变化，获取对应应用列表
watch(activeTab, async () => {
  try {
    const res = await getAppListApi({ type: activeTab.value })
    if (activeTab.value === 'office') {
      officeApps.value = res.data
    } else if (activeTab.value === 'business') {
      businessApps.value = res.data
    } else {
      toolApps.value = res.data
    }
  } catch (error) {
    console.error('获取应用列表失败：', error)
  }
}, { immediate: true })

// 打开应用
const openApp = (app: AppItem) => {
  switch (app.name) {
    case 'OA系统':
      router.push('/')
      break
    case '企业邮箱':
      router.push('/email')
      break
    case '通讯录':
      router.push('/contact')
      break
    case '考勤管理':
      router.push('/calendar')
      break
    default:
      alert(`打开应用：${app.name}\n该应用正在开发中...`)
  }
}
</script>

<style scoped>
.apps-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.app-card {
  text-align: center;
  padding: 30px 20px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  margin-bottom: 20px;
  cursor: pointer;
  transition: all 0.3s;
  position: relative;
}

.app-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px 0 rgba(0, 0, 0, 0.1);
  border-color: #e8f4ff;
  background-color: #f8f9fa;
}

.app-desc {
  font-size: 12px;
  color: #999;
  margin-top: 8px;
}

.app-tag {
  position: absolute;
  top: 10px;
  right: 10px;
  background-color: #2f54eb;
  color: white;
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
}
</style>
