<template>
  <div class="email-page">
    <el-card class="page-header">
      <template #header>
        <span>电子邮件</span>
      </template>
      <p>您的企业邮箱列表（未读/已读）</p>
    </el-card>

    <!-- 邮件筛选栏 -->
    <el-card style="margin-bottom: 20px;">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-select v-model="emailType" placeholder="邮件类型" size="small">
            <el-option label="全部邮件" value="all" />
            <el-option label="未读邮件" value="unread" />
            <el-option label="已读邮件" value="read" />
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-input v-model="searchKeyword" placeholder="搜索邮件主题/发件人" size="small" />
        </el-col>
      </el-row>
    </el-card>

    <!-- 邮件列表 -->
    <el-card>
      <el-table :data="emailList" border style="width: 100%" :row-class-name="tableRowClassName">
        <el-table-column prop="subject" label="邮件主题" min-width="300" />
        <el-table-column prop="sender" label="发件人" width="150" />
        <el-table-column prop="time" label="发送时间" width="180" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button type="text" @click="viewEmail(row.id)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { getEmailListApi, markEmailReadApi } from '@/api/email'

// 类型定义
interface EmailItem {
  id: number
  subject: string
  sender: string
  time: string
  read: boolean
}

// 响应式数据
const emailType = ref('all')
const searchKeyword = ref('')
const emailList = ref<EmailItem[]>([])

// 监听筛选条件变化，获取邮件列表
watch([emailType, searchKeyword], async () => {
  try {
    const res = await getEmailListApi({
      type: emailType.value,
      keyword: searchKeyword.value
    })
    emailList.value = res.data
  } catch (error) {
    console.error('获取邮件列表失败：', error)
    emailList.value = []
  }
}, { immediate: true })

// 未读邮件样式
const tableRowClassName = ({ row }: { row: EmailItem }) => {
  return row.read ? '' : 'unread-email'
}

// 查看邮件（标记为已读）
const viewEmail = async (id: number) => {
  try {
    // 标记为已读
    await markEmailReadApi(id)
    // 刷新邮件列表
    const res = await getEmailListApi({
      type: emailType.value,
      keyword: searchKeyword.value
    })
    emailList.value = res.data
    // 获取邮件详情（可扩展弹窗）
    const email = emailList.value.find(item => item.id === id)
    alert(`查看邮件：${email?.subject}`)
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (error) {
    ElMessage.error('查看邮件失败')
  }
}
</script>

<style scoped>
.email-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

/* 未读邮件高亮 */
:deep(.unread-email) {
  background-color: #f8f9fa;
  font-weight: 600;
}
</style>
