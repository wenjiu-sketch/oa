<template>
  <div class="report-page">
    <el-card class="page-header">
      <template #header>
        <span>工作汇报</span>
      </template>
      <p>周/月/季度工作汇报提交与查看</p>
    </el-card>

    <!-- 汇报操作栏 -->
    <el-card style="margin-bottom: 20px;">
      <el-button type="primary" @click="showAddDialog = true">+ 新建汇报</el-button>
    </el-card>

    <!-- 汇报列表 -->
    <el-card>
      <el-table :data="reportList" border style="width: 100%">
        <el-table-column prop="title" label="汇报标题" min-width="200" />
        <el-table-column prop="type" label="汇报类型">
          <template #default="{ row }">
            <el-tag :type="row.type === '周报' ? 'primary' : 'success'">
              {{ row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="period" label="汇报周期" width="180" />
        <el-table-column prop="status" label="状态">
          <template #default="{ row }">
            <el-tag :type="row.status === '已提交' ? 'success' : 'warning'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button type="text" @click="viewReport(row.id)">查看</el-button>
            <el-button type="text" @click="editReport(row.id)" v-if="row.status === '草稿'">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新建/编辑汇报弹窗 -->
    <el-dialog v-model="showAddDialog" title="新建工作汇报" width="600px">
      <el-form :model="newReport" label-width="80px">
        <el-form-item label="汇报标题">
          <el-input v-model="newReport.title" placeholder="例如：1月份工作汇报" />
        </el-form-item>
        <el-form-item label="汇报类型">
          <el-select v-model="newReport.type">
            <el-option label="周报" value="周报" />
            <el-option label="月报" value="月报" />
            <el-option label="季报" value="季报" />
          </el-select>
        </el-form-item>
        <el-form-item label="汇报周期">
          <el-input v-model="newReport.period" placeholder="例如：2026年1月" />
        </el-form-item>
        <el-form-item label="汇报内容">
          <el-input v-model="newReport.content" type="textarea" :rows="8" placeholder="请输入工作内容、成果、问题、计划等" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="saveReport">保存草稿</el-button>
        <el-button type="success" @click="submitReport">提交</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getReportListApi, saveReportDraftApi, submitReportApi } from '@/api/report'

// 类型定义
interface ReportItem {
  id: number
  title: string
  type: string
  period: string
  status: '草稿' | '已提交'
  content: string
}

// 响应式数据
const showAddDialog = ref(false)
const newReport = ref({
  title: '',
  type: '周报',
  period: '',
  content: '',
  status: '草稿'
})
const reportList = ref<ReportItem[]>([])

// 页面加载时获取汇报列表
onMounted(async () => {
  await loadReports()
})

// 加载汇报数据
const loadReports = async () => {
  try {
    const res = await getReportListApi()
    reportList.value = res.data
  } catch (error) {
    console.error('获取汇报列表失败：', error)
    reportList.value = []
  }
}

// 保存草稿
const saveReport = async () => {
  try {
    await saveReportDraftApi(newReport.value)
    showAddDialog.value = false
    resetNewReport()
    await loadReports()
    ElMessage.success('草稿保存成功！')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (error) {
    ElMessage.error('保存失败')
  }
}

// 提交汇报
const submitReport = async () => {
  try {
    await submitReportApi(newReport.value)
    showAddDialog.value = false
    resetNewReport()
    await loadReports()
    ElMessage.success('汇报提交成功！')
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (error) {
    ElMessage.error('提交失败')
  }
}

// 重置表单
const resetNewReport = () => {
  newReport.value = {
    title: '',
    type: '周报',
    period: '',
    content: '',
    status: '草稿'
  }
}

// 查看汇报
const viewReport = (id: number) => {
  const report = reportList.value.find(item => item.id === id)
  if (report) {
    alert(`查看汇报：${report.title}\n\n内容：${report.content.substring(0, 100)}...`)
  }
}

// 编辑汇报
const editReport = (id: number) => {
  const report = reportList.value.find(item => item.id === id)
  if (report) {
    newReport.value = { ...report }
    showAddDialog.value = true
  }
}
</script>

<style scoped>
.report-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}
</style>
