<template>
  <div class="contact-page">
    <el-card class="page-header">
      <template #header>
        <span>通讯录</span>
      </template>
      <p>公司员工通讯录（按部门分类）</p>
    </el-card>

    <!-- 部门筛选 -->
    <el-card style="margin-bottom: 20px;">
      <el-select v-model="selectedDept" placeholder="选择部门" style="width: 200px;">
        <el-option label="全部部门" value="all" />
        <el-option label="技术部" value="技术部" />
        <el-option label="行政部" value="行政部" />
        <el-option label="人事部" value="人事部" />
        <el-option label="财务部" value="财务部" />
      </el-select>
    </el-card>

    <!-- 通讯录列表 -->
    <el-card>
      <el-table :data="filteredContacts" border style="width: 100%">
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="dept" label="部门" width="120" />
        <el-table-column prop="position" label="职位" width="150" />
        <el-table-column prop="phone" label="手机号" width="150" />
        <el-table-column prop="email" label="邮箱" min-width="200" />
        <el-table-column prop="office" label="办公位" width="120" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button type="text" @click="showContactDetail(row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 联系人详情弹窗 -->
    <el-dialog v-model="detailVisible" title="联系人详情" width="400px">
      <div v-if="selectedContact" class="contact-detail">
        <el-avatar :src="selectedContact.avatar" size="large" style="margin-bottom: 20px;" />
        <p><strong>姓名：</strong>{{ selectedContact.name }}</p>
        <p><strong>部门：</strong>{{ selectedContact.dept }}</p>
        <p><strong>职位：</strong>{{ selectedContact.position }}</p>
        <p><strong>手机号：</strong>{{ selectedContact.phone }}</p>
        <p><strong>邮箱：</strong>{{ selectedContact.email }}</p>
        <p><strong>办公位：</strong>{{ selectedContact.office }}</p>
        <p><strong>入职时间：</strong>{{ selectedContact.joinTime }}</p>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">

import { ref, watch } from 'vue'
import { getContactListApi } from '@/api/contact'

// 定义联系人类型接口
interface ContactItem {
  name: string
  dept: string
  position: string
  phone: string
  email: string
  office: string
  joinTime: string
  avatar: string
}

// 响应式数据
const selectedDept = ref<string>('all')
const detailVisible = ref<boolean>(false)
const selectedContact = ref<ContactItem | null>(null)
const filteredContacts = ref<ContactItem[]>([])

// 监听部门变化，获取通讯录数据
watch(selectedDept, async () => {
  try {
    const res = await getContactListApi({ dept: selectedDept.value })
    filteredContacts.value = res.data
  } catch (error) {
    console.error('获取通讯录失败：', error)
    filteredContacts.value = []
  }
}, { immediate: true })

// 显示联系人详情
const showContactDetail = (contact: ContactItem) => {
  selectedContact.value = contact
  detailVisible.value = true
}
</script>

<style scoped>
.contact-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.contact-detail {
  line-height: 2;
}
</style>
