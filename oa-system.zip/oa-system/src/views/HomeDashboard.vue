<template>
  <div class="dashboard-container">
    <!-- 待办统计卡片 -->
    <el-card class="todo-stats-card" shadow="hover">
      <template #header>
        <div class="card-header">待办统计</div>
      </template>
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="stats-item">
            <div class="stats-num">{{ todoStats.pending }}</div>
            <div class="stats-text">待处理</div>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="stats-item">
            <div class="stats-num">{{ todoStats.processing }}</div>
            <div class="stats-text">处理中</div>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="stats-item">
            <div class="stats-num">{{ todoStats.completed }}</div>
            <div class="stats-text">已完成</div>
          </div>
        </el-col>
      </el-row>
    </el-card>

    <!-- 常用功能 + 天气 -->
    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="16">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">常用功能</div>
          </template>
          <el-row :gutter="10">
            <!-- 修复：直接渲染兜底数据，避免接口返回异常导致功能列表为空 -->
            <el-col :span="4" v-for="item in functionList" :key="item.name">
              <div class="func-item" @click="goToPage(item.path)">
                <el-icon :size="24" class="func-icon"><component :is="item.icon" /></el-icon>
                <div class="func-name">{{ item.name }}</div>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">今日天气</div>
          </template>
          <div class="weather-info">
            <div class="weather-icon">{{ weather.icon }}</div>
            <div class="weather-text">{{ weather.text }} {{ weather.temp }}℃</div>
            <div class="weather-tips">{{ weather.tips }}</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 进行中待办 + 日程 -->
    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="16">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">进行中待办</div>
          </template>
          <el-table :data="processingTodos" border style="width: 100%;">
            <el-table-column prop="id" label="编号" width="80" />
            <el-table-column prop="title" label="待办标题" />
            <el-table-column prop="user" label="负责人" width="100" />
            <el-table-column prop="time" label="创建时间" width="180" />
          </el-table>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">今日日程</div>
          </template>
          <div class="calendar-list">
            <div class="calendar-item" v-for="item in todaySchedule" :key="item.id">
              <div class="calendar-time">{{ item.time }}</div>
              <div class="calendar-content">{{ item.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  Notification, Calendar, User, Clock, Message, Files // 修复：补全Files图标导入
} from '@element-plus/icons-vue'
// 注释掉不存在的API，避免加载失败（如果有真实API再解开）
// import { getDashboardDataApi } from '@/api/dashboard'

// 类型定义
interface FunctionItem {
  name: string
  icon: unknown
  path: string
}
interface TodoStats {
  pending: number
  processing: number
  completed: number
}
interface ProcessingTodo {
  id: number
  title: string
  user: string
  time: string
}
interface TodaySchedule {
  id: number
  time: string
  title: string
}
interface Weather {
  icon: string
  text: string
  temp: number
  tips: string
}

// 响应式数据
const router = useRouter()
// 修复：直接初始化兜底数据，不再依赖接口，避免数据加载失败导致功能列表为空
const functionList = ref<FunctionItem[]>([
  { name: '电子邮件', icon: Message, path: '/email' },
  { name: '公告通知', icon: Notification, path: '/notice' },
  { name: '我的日程', icon: Calendar, path: '/calendar' },
  { name: '考勤统计', icon: Clock, path: '/attendance' },
  { name: '工作汇报', icon: Files, path: '/report' }, // 修复：File改为Files
  { name: '通讯录', icon: User, path: '/contact' }
])
const todoStats = ref<TodoStats>({ pending: 5, processing: 2, completed: 10 })
const processingTodos = ref<ProcessingTodo[]>([
  { id: 1, title: '完成月度总结', user: '张三', time: '2026-01-28 09:00' },
  { id: 2, title: '对接客户需求', user: '李四', time: '2026-01-28 10:30' }
])
const todaySchedule = ref<TodaySchedule[]>([
  { id: 1, time: '09:00', title: '项目晨会' },
  { id: 2, time: '14:00', title: '技术分享会' },
  { id: 3, time: '16:00', title: '周报评审' }
])
const weather = ref<Weather>({
  icon: '☀️',
  text: '晴',
  temp: 25,
  tips: '今日天气晴朗，注意防晒'
})

// 页面加载时获取数据（注释掉接口请求，避免报错）
onMounted(async () => {
  try {
    // 真实项目中解开以下代码，注释掉上面的兜底数据
    // const res = await getDashboardDataApi()
    // functionList.value = res.data.functionList
    // todoStats.value = res.data.todoStats
    // processingTodos.value = res.data.processingTodos
    // todaySchedule.value = res.data.todaySchedule
    // weather.value = res.data.weather
  } catch (error) {
    console.error('获取首页数据失败：', error)
    // 兜底数据已提前初始化，无需重复赋值
  }
})

// 修复：优化跳转逻辑，强制路由刷新，避免组件复用
const goToPage = (path: string) => {
  // 使用replace避免历史记录堆积，同时强制刷新
  router.replace({
    path,
    // 加随机参数强制触发路由更新
    query: { t: new Date().getTime() }
  }).catch(err => {
    console.error('跳转失败：', err)
    // 终极兜底：原生跳转（仅在Vue路由失效时生效）
    window.location.href = path
  })
}
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}
.card-header {
  font-size: 16px;
  font-weight: 600;
}
.todo-stats-card {
  margin-bottom: 0;
}
.stats-item {
  text-align: center;
  padding: 10px 0;
}
.stats-num {
  font-size: 24px;
  font-weight: 700;
  color: #409eff;
}
.stats-text {
  font-size: 14px;
  color: #666;
  margin-top: 5px;
}
.func-item {
  text-align: center;
  padding: 15px 0;
  cursor: pointer;
  border-radius: 8px;
  transition: background-color 0.3s;
}
.func-item:hover {
  background-color: #f0f9ff;
}
.func-icon {
  color: #409eff;
  margin-bottom: 5px;
}
.func-name {
  font-size: 14px;
  color: #333;
}
.weather-info {
  text-align: center;
  padding: 10px 0;
}
.weather-icon {
  font-size: 48px;
  margin-bottom: 10px;
}
.weather-text {
  font-size: 16px;
  font-weight: 600;
  color: #333;
}
.weather-tips {
  font-size: 14px;
  color: #666;
  margin-top: 5px;
}
.calendar-list {
  padding: 10px 0;
}
.calendar-item {
  display: flex;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}
.calendar-time {
  width: 80px;
  font-size: 14px;
  color: #999;
}
.calendar-content {
  flex: 1;
  font-size: 14px;
  color: #333;
}
</style>
