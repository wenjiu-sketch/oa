<template>
  <div class="calendar-page">
    <el-card class="page-header">
      <template #header>
        <span>我的日程</span>
      </template>
      <p>管理您的个人日程安排</p>
    </el-card>

    <!-- 日历视图 -->
    <el-card class="calendar-card">
      <el-calendar v-model="selectedDate" class="full-calendar">
        <template #date-cell="{ data }">
          <div class="calendar-cell" @click="openDialog('add', data.day)">
            {{ data.day.split('-').slice(2).join('-') }}
            <div v-for="event in getEvents(data.day)" :key="event.id" class="event">
              <span class="event-time">{{ event.time }}</span>
              <span class="event-title">{{ event.title }}</span>
              <div class="event-actions" v-if="event.id > 4">
                <el-button type="text" size="small" @click.stop="openDialog('edit', data.day, event)">
                  编辑
                </el-button>
                <el-button type="text" size="small" text color="red" @click.stop="deleteEvent(event.id)">
                  删除
                </el-button>
              </div>
            </div>
            <div class="add-event" @click.stop="openDialog('add', data.day)">+ 添加</div>
          </div>
        </template>
      </el-calendar>
    </el-card>

    <!-- 今日日程列表 -->
    <el-card class="today-events">
      <template #header>
        <span>今日日程</span>
      </template>
      <el-timeline>
        <el-timeline-item
          v-for="event in todayEvents"
          :key="event.id"
          :timestamp="event.time"
        >
          {{ event.title }}
          <div class="timeline-actions" v-if="event.id > 4">
            <el-button
              type="text"
              size="small"
              @click="openDialog('edit', selectedDateStr, event)"
            >
              编辑
            </el-button>
            <el-button type="text" size="small" text color="red" @click="deleteEvent(event.id)">
              删除
            </el-button>
          </div>
        </el-timeline-item>
      </el-timeline>
    </el-card>

    <!-- 新增/编辑日程弹窗 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="400px">
      <el-form :model="formEvent" label-width="80px">
        <el-form-item label="日程标题" required>
          <el-input v-model="formEvent.title" placeholder="请输入日程标题" />
        </el-form-item>
        <el-form-item label="开始时间" required>
          <el-input v-model="formEvent.time" placeholder="例如：14:00" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="formEvent.remark" type="textarea" :rows="3" placeholder="可选：添加日程备注信息" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveEvent">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getCalendarListApi, addCalendarApi, editCalendarApi, deleteCalendarApi } from '@/api/calendar'

// 类型定义
interface CalendarEvent {
  id: number
  date: string
  time: string
  title: string
  remark: string
}

// 响应式数据
const selectedDate = ref<Date>(new Date())
const dialogVisible = ref<boolean>(false)
const dialogType = ref<'add' | 'edit'>('add')
const currentDate = ref<string>('')
const events = ref<CalendarEvent[]>([])

// 表单数据
const formEvent = ref<CalendarEvent>({
  id: 0,
  title: '',
  time: '',
  remark: '',
  date: ''
})

// 获取指定日期的日程
const getEvents = (date: string): CalendarEvent[] => {
  return events.value.filter(event => event.date === date)
}

// 今日日期字符串
const selectedDateStr = computed<string>(() => {
  const date = selectedDate.value
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
})

// 今日日程
const todayEvents = computed<CalendarEvent[]>(() => {
  return events.value.filter(event => event.date === selectedDateStr.value)
})

// 弹窗标题
const dialogTitle = computed<string>(() => {
  return dialogType.value === 'add' ? '新增日程' : '编辑日程'
})

// 页面加载时获取日程列表
onMounted(async () => {
  await loadEvents()
})

// 加载日程数据
const loadEvents = async () => {
  try {
    const res = await getCalendarListApi()
    events.value = res.data
  } catch (error) {
    console.error('获取日程失败：', error)
    events.value = []
  }
}

// 打开弹窗
const openDialog = (type: 'add' | 'edit', date: string, event?: CalendarEvent): void => {
  dialogType.value = type
  currentDate.value = date

  if (type === 'add') {
    formEvent.value = {
      id: 0,
      title: '',
      time: '',
      remark: '',
      date: date
    }
  } else if (type === 'edit' && event) {
    formEvent.value = { ...event }
  }

  dialogVisible.value = true
}

// 保存日程
const saveEvent = async (): Promise<void> => {
  if (!formEvent.value.title.trim() || !formEvent.value.time.trim()) {
    ElMessage.warning('标题和时间不能为空！')
    return
  }

  try {
    if (dialogType.value === 'add') {
      await addCalendarApi(formEvent.value)
      ElMessage.success('新增日程成功！')
    } else {
      await editCalendarApi(formEvent.value.id, formEvent.value)
      ElMessage.success('编辑日程成功！')
    }
    dialogVisible.value = false
    await loadEvents() // 刷新日程
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

// 删除日程
const deleteEvent = async (id: number): Promise<void> => {
  if (confirm('确定要删除该日程吗？')) {
    try {
      await deleteCalendarApi(id)
      ElMessage.success('日程删除成功！')
      await loadEvents()
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (error) {
      ElMessage.error('删除失败')
    }
  }
}
</script>

<style scoped>
.calendar-page {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.calendar-card {
  margin-bottom: 20px;
  transition: all 0.3s;
}

.calendar-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px 0 rgba(0, 0, 0, 0.1);
}

:deep(.full-calendar .el-calendar) {
  width: 100%;
}

.calendar-cell {
  height: 100px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.event {
  font-size: 12px;
  color: #2f54eb;
  margin-top: 4px;
  background: #e6f7ff;
  padding: 4px 6px;
  border-radius: 6px;
  width: 90%;
  text-align: left;
  position: relative;
  line-height: 1.5;
}
.event-time {
  font-size: 11px;
  color: #666;
  margin-right: 6px;
  background: #f0f7ff;
  padding: 1px 4px;
  border-radius: 3px;
}

.event-title {
  font-size: 12px;
  color: #2f54eb;
}

.event-actions {
  font-size: 10px;
  margin-top: 2px;
  display: flex;
  gap: 4px;
  opacity: 0;
  transition: opacity 0.2s;
}
.event:hover .event-actions {
  opacity: 1;
}
.add-event {
  font-size: 12px;
  color: #2f54eb;
  margin-top: 6px;
  cursor: pointer;
  padding: 2px 8px;
  border: 1px dashed #b7d5ff;
  border-radius: 4px;
}
.add-event:hover {
  background: #f0f7ff;
}

.today-events {
  transition: all 0.3s;
}

.today-events:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px 0 rgba(0, 0, 0, 0.1);
}

.timeline-actions {
  margin-top: 8px;
  font-size: 12px;
}
</style>
