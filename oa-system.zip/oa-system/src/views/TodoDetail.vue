<template>
  <div class="todo-detail-container">
    <el-card>
      <template #header>
        <span>待办详情 - {{ detail.title }}</span>
        <el-button @click="$router.back()" type="text">返回</el-button>
      </template>
      <el-descriptions :column="2" border>
        <el-descriptions-item label="编号">{{ detail.id }}</el-descriptions-item>
        <el-descriptions-item label="申请人">{{ detail.user }}</el-descriptions-item>
        <el-descriptions-item label="申请时间">{{ detail.time }}</el-descriptions-item>
        <el-descriptions-item label="状态">{{ detail.status }}</el-descriptions-item>
        <el-descriptions-item label="详情" :span="2">
          {{ detail.content }}
        </el-descriptions-item>
      </el-descriptions>
      <div class="action-buttons">
        <el-button type="primary"  @click="updateTodoStatus(Number(detail.id), 'completed')">同意</el-button>
        <el-button type="danger" @click="updateTodoStatus(Number(detail.id), 'rejected')">驳回</el-button>
        <el-button>转办</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { getTodoDetailApi,updateTodoStatusApi } from '@/api/todo'
import { ElMessage } from 'element-plus'

// 定义详情数据类型
interface TodoDetail {
  id: string | number
  title: string
  user: string
  time: string
  status: 'processing' | 'completed' | 'rejected'
  content: string
}

const route = useRoute()
const detail = ref<TodoDetail>({
  id: '',
  title: '',
  user: '',
  time: '',
  status:  'processing',
  content: ''
})

onMounted(async() => {
  // 获取路由参数并添加类型断言
  const id=Number(route.params.id)
  try{
    const res=await getTodoDetailApi(id)
    detail.value=res.data
  }catch(error){
    console.error('获取详情失败：',error)
    ElMessage.error('获取待办详情失败')
  }
})
//更新待办状态
const updateTodoStatus=async(id:number,status:string)=>{
  try{
    await updateTodoStatusApi(id,status)
      ElMessage.success('操作成功')
    // 刷新详情
    const res = await getTodoDetailApi(id)
    detail.value = res.data
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  } catch (error) {
    ElMessage.error('操作失败')
  }
}
</script>

<style scoped>
.todo-detail-container {
  padding: 20px;
}
.action-buttons {
  margin-top: 20px;
  text-align: right;
}
</style>
