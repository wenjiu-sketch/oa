<template>
  <div class="attendance-page">
    <el-card class="page-header">
      <template #header>
        <span>考勤统计</span>
      </template>
      <p>本月考勤详情统计与历史记录</p>
    </el-card>

    <!-- 月度考勤概览 -->
    <el-row :gutter="20" style="margin-bottom: 20px;">
      <el-col :span="12">
        <el-card class="stat-card">
          <h4>月度考勤概览</h4>
          <v-chart :option="monthChartOption" :autoresize="true" style="height: 250px;" />
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card class="stat-card">
          <h4>考勤趋势</h4>
          <v-chart :option="trendChartOption" :autoresize="true" style="height: 250px;" />
        </el-card>
      </el-col>
    </el-row>

    <!-- 考勤记录列表 -->
    <el-card>
      <template #header>
        <span>考勤记录</span>
      </template>
      <el-table :data="attendanceList" border style="width: 100%">
        <el-table-column prop="date" label="日期" />
        <el-table-column prop="checkIn" label="上班打卡" />
        <el-table-column prop="checkOut" label="下班打卡" />
        <el-table-column prop="status" label="状态">
          <template #default="{ row }">
            <el-tag :type="row.status === '正常' ? 'success' : 'warning'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">

import { ref,onMounted } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
// 1. 新增 GridComponent 导入（核心修复）
import { CanvasRenderer } from 'echarts/renderers'
import { PieChart, LineChart } from 'echarts/charts'
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent // 折线图必须的网格组件
} from 'echarts/components'
import { getAttendanceDataApi } from '@/api/attendance'
// 2. 注册 GridComponent（核心修复）
use([
  CanvasRenderer,
  PieChart,
  LineChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent // 新增注册
])

// 月度考勤饼图（保持不变）
const monthChartOption = ref({
  tooltip: { trigger: 'item' },
  legend: { orient: 'vertical', right: 10, top: 'center' },
  series: [
    {
      name: '月度考勤',
      type: 'pie',
      radius: ['40%', '70%'],
      data: [ ]
    }
  ]
})

// 考勤趋势折线图（核心修复）
const trendChartOption = ref({
  tooltip: { trigger: 'axis' },
  // 3. 新增 grid 配置（核心修复：让图表占满容器）
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true // 确保标签显示在容器内
  },
  xAxis: {
    type: 'category',
    data: ['1月', '2月', '3月', '4月', '5月', '6月'],
    axisLine: { show: true } // 显示x轴线条
  },
  yAxis: {
    type: 'value',
    axisLine: { show: true } // 显示y轴线条
  },
  series: [
    {
      name: '正常打卡天数',
      type: 'line',
      data: [],
      lineStyle: {
        width: 2, // 线条宽度
        color: '#2f54eb' // 线条颜色
      },
      itemStyle: {
        color: '#2f54eb' // 拐点颜色
      }
    }
  ]
})

// 考勤记录数据（保持不变）
const attendanceList = ref([])
// 页面加载时获取数据
onMounted(async () => {
  try {
    const res = await getAttendanceDataApi()
    // 赋值考勤数据
   if (monthChartOption.value.series[0]) {
  monthChartOption.value.series[0].data = res.data.monthChart;
}
if (trendChartOption.value.series[0]) {
  trendChartOption.value.series[0].data = res.data.trendChart;
}
    attendanceList.value = res.data.attendanceList
  } catch (error) {
    console.error('获取考勤数据失败：', error)
  }
})
</script>

<style scoped>
.attendance-page {
  padding: 20px;
}
.page-header {
  margin-bottom: 20px;
}
.stat-card {
  transition: all 0.3s;
}
.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px 0 rgba(0, 0, 0, 0.1);
}
/* 可选：给图表容器加边框，更美观 */
:deep(.stat-card .el-card__body) {
  padding: 15px;
}
</style>
