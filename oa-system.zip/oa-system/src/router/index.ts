import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { useUserStore } from '@/stores/user';

// 页面组件（直接绑定布局）
const HomeDashboard = () => import('../views/HomeDashboard.vue')
const TodoList = () => import('../views/TodoList.vue')
const TodoDetail = () => import('../views/TodoDetail.vue')
const MyCalendar = () => import('../views/MyCalendar.vue')
const AttendancePage = () => import('../views/AttendancePage.vue')
const EmailPage = () => import('../views/EmailPage.vue')
const NoticePage = () => import('../views/NoticePage.vue')
const ReportPage = () => import('../views/ReportPage.vue')
const ContactPage = () => import('../views/ContactPage.vue')
const AppPage = () => import('../views/AppPage.vue')
const LoginPage = () => import('../views/LoginPage.vue')

// 路由配置（扁平化，每个页面都带布局）
const routes: Array<RouteRecordRaw> = [
  // 登录页（无布局）
  {
    path: '/login',
    name: 'Login',
    component: LoginPage,
    meta: { title: '登录 - OA办公系统' }
  },

  // 首页（带布局）
  {
    path: '/',
    name: 'Dashboard',
    component: () => import('../layouts/MainLayout.vue'), // 布局作为主组件
    meta: { requiresAuth: true, title: 'OA办公系统' },
    children: [{ path: '', component: HomeDashboard }] // 内容作为子组件
  },

  // 待办列表（带布局）
  {
    path: '/todo',
    name: 'TodoList',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '待办工作 - OA办公系统' },
    children: [{ path: '', component: TodoList }]
  },

  // 待办详情（带布局）
  {
    path: '/todo/:id',
    name: 'TodoDetail',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '待办详情 - OA办公系统' },
    children: [{ path: '', component: TodoDetail }]
  },

  // 考勤统计（带布局）
  {
    path: '/attendance',
    name: 'Attendance',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '考勤统计 - OA办公系统' },
    children: [{ path: '', component: AttendancePage }]
  },

  // 电子邮件（带布局）
  {
    path: '/email',
    name: 'Email',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '电子邮件 - OA办公系统' },
    children: [{ path: '', component: EmailPage }]
  },

  // 其他页面按相同格式添加...
  {
    path: '/calendar',
    name: 'MyCalendar',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '我的日程 - OA办公系统' },
    children: [{ path: '', component: MyCalendar }]
  },
  {
    path: '/notice',
    name: 'Notice',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '公告通知 - OA办公系统' },
    children: [{ path: '', component: NoticePage }]
  },
  {
    path: '/report',
    name: 'Report',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '工作汇报 - OA办公系统' },
    children: [{ path: '', component: ReportPage }]
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '通讯录 - OA办公系统' },
    children: [{ path: '', component: ContactPage }]
  },
  {
    path: '/apps',
    name: 'Apps',
    component: () => import('../layouts/MainLayout.vue'),
    meta: { requiresAuth: true, title: '应用中心 - OA办公系统' },
    children: [{ path: '', component: AppPage }]
  },

  // 重定向
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  // 强制路由切换时滚动到顶部
  scrollBehavior() {
    return { top: 0 }
  }
})

// 路由守卫（简化版，避免异步问题）
router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title as string
  }

  // 跳过登录页的权限验证
  if (to.path === '/login') {
    next()
    return
  }

  // 同步验证登录状态（Pinia 已初始化）
  const userStore = useUserStore()
  if (!userStore.isLoggedIn) {
    next('/login')
  } else {
    next()
  }
})

export default router
