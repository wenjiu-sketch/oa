// src/mock/index.ts
import Mock from 'mockjs';

// 设置请求延迟（模拟真实接口）
Mock.setup({
  timeout: '300-800'
});

// 1. 模拟登录接口
Mock.mock('/api/login', 'post', (req: { body: string }) => {
  // 明确 req 类型为 { body: string }，避免 TypeScript 报错
  const { username, password } = JSON.parse(req.body);

  // 模拟账号密码验证（企业级会对接数据库）
  if (username === 'admin' && password === '123456') {
    return {
      code: 200,
      msg: '登录成功',
      data: {
        token: Mock.Random.guid(), // 随机生成token
        userInfo: {
          id: 1,
          name: '李佳',
          role: 'admin',
          avatar: ''
        }
      }
    };
  } else {
    return {
      code: 400,
      msg: '用户名或密码错误'
    };
  }
});

// 2. 模拟待办列表接口（适配你的TodoList页面）
Mock.mock('/api/todo/list', 'get', () => {
  return {
    code: 200,
    msg: '请求成功',
    data: {
      list: [
        { id: 1, title: '20250001号审批单', user: '李佳', time: '2024-12-29 10:32:46', status: 'processing' },
        { id: 2, title: '印章使用审批', user: '李佳', time: '2026-01-24 20:17:08', status: 'processing' },
        { id: 3, title: '出差申请单', user: '李佳', time: '2026-01-24 17:47:38', status: 'processing' },
        { id: 4, title: '办公用品申领', user: '李佳', time: '2026-01-20 09:15:22', status: 'processing' }
      ],
      total: 4
    }
  };
});

// 3. 模拟日程列表接口（适配你的MyCalendar页面）
Mock.mock('/api/calendar/list', 'get', () => {
  return {
    code: 200,
    msg: '请求成功',
    data: [
      { id: 1, day: '2026-01-26', content: '项目评审会 14:00' },
      { id: 2, day: '2026-01-28', content: '部门周会 10:00' },
      { id: 3, day: '2026-02-01', content: '春节放假通知' }
    ]
  };
});

console.log('Mock接口已启动');
export default Mock;
