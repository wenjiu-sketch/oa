# 🎯 OA办公系统
基于 Vue3 + TypeScript + Element Plus 开发的企业级办公自动化系统，提供待办管理、考勤统计、日程安排等核心办公功能，适配多端办公场景。


## 📋 项目介绍
本项目是一套轻量且完整的企业级OA系统，以「简洁高效」为核心设计理念，覆盖日常办公的核心流程，同时具备完善的权限控制与工程化规范，可直接用于企业内部办公或二次开发拓展。


## ✨ 核心特性
- 🚀 **技术栈现代化**：Vue3 + TypeScript + Pinia 构建，代码类型安全、可维护性强
- 🔒 **权限体系完善**：登录鉴权、Token持久化、过期自动登出，保障企业数据安全
- 📦 **工程化标准**：Axios请求封装、环境变量区分、路由懒加载，符合企业级开发规范
- 🎨 **专业UI体验**：基于Element Plus构建，界面简洁高效，交互流畅自然
- 📱 **多端适配**：响应式设计，支持PC端、平板等设备使用


## 🛠️ 技术栈
| 技术工具       | 版本       | 用途                  |
|----------------|------------|-----------------------|
| Vue            | 3.4+       | 前端框架              |
| TypeScript     | 5.3+       | 类型安全              |
| Element Plus   | 2.5+       | UI组件库              |
| Pinia          | 2.1+       | 状态管理              |
| Axios          | 1.6+       | HTTP请求              |
| Vue Router     | 4.2+       | 路由管理              |
| Mock.js        | 1.1+       | 接口模拟              |
| Vite           | 5.0+       | 构建工具              |
| ESLint         | 8.50+      | 代码规范检查          |


## 🚀 快速开始
### 环境要求
- Node.js >= 18.0.0
- npm >= 9.0.0


### 项目初始化
```sh
# 安装依赖
npm install
```


### 开发模式
```sh
npm run dev
```
访问 `http://localhost:5173` 进入系统，默认账号：`admin` / `123456`


### 生产构建
```sh
# 类型检查 + 编译打包
npm run build
```


### 代码规范检查
```sh
npm run lint
```


### 测试相关
```sh
# 单元测试
npm run test:unit

# 端到端测试（开发环境）
npm run test:e2e:dev

# 端到端测试（生产环境）
npm run build
npm run test:e2e
```


## 📋 功能模块
### 1. 核心办公功能
- ✅ **待办管理**：待办列表、详情查看、状态跟踪
- ✅ **考勤统计**：月度考勤数据、异常打卡提醒
- ✅ **日程安排**：日历视图、日程管理、会议提醒
- ✅ **常用工具**：邮件、公告、工作汇报、通讯录


### 2. 系统基础功能
- ✅ **用户登录**：账号验证、Token持久化
- ✅ **权限控制**：路由守卫、接口鉴权
- ✅ **错误处理**：全局异常捕获、友好提示
- ✅ **状态管理**：全局状态共享、本地存储


## 📁 项目结构
```
OA-SYSTEM/
├── src/
│   ├── api/          # 接口请求封装
│   ├── assets/       # 静态资源（图片、样式）
│   ├── components/   # 公共UI组件
│   ├── router/       # 路由配置
│   ├── stores/       # Pinia状态管理
│   ├── utils/        # 工具函数（请求、权限等）
│   ├── views/        # 页面视图（待办、考勤等）
│   ├── App.vue       # 根组件
│   └── main.ts       # 入口文件
├── .env.development  # 开发环境变量
├── .env.production   # 生产环境变量
└── package.json      # 依赖配置
```


## 📌 开发工具推荐
- **IDE**：VS Code + [Vue (Official)](https://marketplace.visualstudio.com/items?itemName=Vue.volar)（禁用Vetur）
- **浏览器调试**：
  - Chrome/Edge：安装 [Vue.js devtools](https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd)
  - Firefox：安装 [Vue.js devtools](https://addons.mozilla.org/en-US/firefox/addon/vue-js-devtools/)


## 📄 许可证
本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。


## 🤝 贡献指南
1. Fork 本仓库
2. 创建特性分支（`git checkout -b feature/功能名`）
3. 提交代码（`git commit -m '添加xx功能'`）
4. 推送到分支（`git push origin feature/功能名`）
5. 提交 Pull Request